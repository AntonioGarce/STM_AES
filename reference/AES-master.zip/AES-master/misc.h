bool test_aesni_support(void);
