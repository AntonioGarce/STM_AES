void encrypt_file(const char *inpath, const char *outpath, const unsigned char *key);
void decrypt_file(const char *inpath, const char *outpath, const unsigned char *key);
