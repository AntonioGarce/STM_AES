int aes_expand_key(const unsigned char *in_key, unsigned char *out_keys);
void aes_prepare_decryption_keys(const unsigned char *keys);
