void print_hex(const unsigned char *s, size_t len);
